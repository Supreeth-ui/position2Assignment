import React from "react";
import { Link } from "@reach/router";
import "./Home.css";

const Home = () => {
  return (
    <div className="Home p-3">
      <div className="p-5">
        <div className="card">
          <div className="card-body">
            Click on <Link to="/repositories">Repositories</Link> to view list
            of repositories.
          </div>
        </div>
      </div>
      <div className="p-5">
        <div className="card">
          <div className="card-body">
            Click on <Link to="/projects">Projects</Link> to view list of
            projects.
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
