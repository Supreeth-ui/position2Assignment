import React from "react";
import "./SideMenu.css";
import { Link } from "@reach/router";

const SideMenu = (props) => {
  //const updatedClass = `${props.color} SideMenu`;
  return (
    <div className="SideMenu">
      <div className="MenuHeader">
        <i className="fas fa-arrows-alt pr-1"></i>Position-2
      </div>
      <div className="MenuContent">
        <div className="ContentList">
          <Link to="/home" className="MenuName">
            <i class="fas fa-home pr-2"></i>
            <div>Home</div>
          </Link>
        </div>
        <div className="ContentList">
          <Link to="/repositories" className="MenuName">
            <i className="fas fa-retweet pr-2"></i>
            <div>Repositories</div>
          </Link>
        </div>
        <div className="ContentList">
          <Link to="/projects" className="MenuName">
            <i class="far fa-folder pr-2"></i>
            <div>Projects</div>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default SideMenu;
