import React from "react";
import { Router } from "@reach/router";
import "./Content.css";
import Home from "../Home/Home";
import Repositories from "../Repositories/Repositories";
import Projects from "../Projects/Projects";
import CreateProject from "../Projects/CreateProject";
import CreateRepositories from "../Repositories/CreateRepositories";

const Content = () => {
  return (
    <Router style={{ flex: 1 }}>
      <Home path="/home" />
      <Repositories path="/repositories" />
      <Projects path="/projects" />
      <CreateProject path="/projects/createProject" />
      <CreateRepositories path="/repositories/createRepositories" />
    </Router>
  );
};

export default Content;
