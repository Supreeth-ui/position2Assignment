import React, { Component } from "react";
import { navigate } from "@reach/router";
import SideMenu from "./SideMenu/SideMenu";
import Content from "./Content/Content";
import "./App.css";
import ThemeContext from "./ThemeContext/ThemeContext";

class App extends Component {
  state = { theme: ["rgb(7, 71, 166)"] };
  render() {
    navigate("/home");
    return (
      <ThemeContext.Provider value={this.state.theme}>
        <div className="App">
          <SideMenu />
          <Content />
        </div>
      </ThemeContext.Provider>
    );
  }
}

export default App;
