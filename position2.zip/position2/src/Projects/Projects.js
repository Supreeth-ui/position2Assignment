import React, { useState } from "react";
import "./Projects.css";
import { Link } from "@reach/router";
import ThemeContext from "../ThemeContext/ThemeContext";

const Projects = () => {
  const [search, setSearch] = useState("");
  const listOfProjects = [
    {
      id: "1",
      projectName: "Adopt Pet",
      projectKey: "AD",
      projectDescription: "Customer Project",
    },
    {
      id: "2",
      projectName: "Game Builder",
      projectKey: "AC",
      projectDescription: "Customer Game Project",
    },
    {
      id: "3",
      projectName: "Get Insurance",
      projectKey: "GI",
      projectDescription: "Customer Insurance Project",
    },
  ];
  const [projects, setProjects] = useState(listOfProjects);

  const iterateItem = (item) => {
    return item.map(function (nextItem, j) {
      return (
        <tr key={nextItem.id}>
          <td>{nextItem.id}</td>
          <td>{nextItem.projectName}</td>
          <td>{nextItem.projectKey}</td>
          <td>{nextItem.projectDescription}</td>
        </tr>
      );
    });
  };

  function filterProject(event) {
    setSearch(event.target.value);
    let searchString = event.target.value;
    const filtered = listOfProjects.filter(
      (item) =>
        item.id.toLowerCase().includes(searchString.toLowerCase()) ||
        item.projectName.toLowerCase().includes(searchString.toLowerCase()) ||
        item.projectKey.toLowerCase().includes(searchString.toLowerCase()) ||
        item.projectDescription
          .toLowerCase()
          .includes(searchString.toLowerCase())
    );
    console.log("filtered ", filtered);
    if (searchString.trim() !== "") {
      setProjects(filtered);
    } else if (searchString.trim() === "") {
      setProjects(listOfProjects);
    }
  }
  return (
    <div className="content">
      <header>
        <div className="contentHeader">
          <h4>Projects</h4>
          <ThemeContext.Consumer>
            {([theme]) => (
              <Link to="/projects/createProject">
                <button className="btn" style={{ backgroundColor: theme }}>
                  Create Project
                </button>
              </Link>
            )}
          </ThemeContext.Consumer>
          {/* <button> Create Project</button> */}
        </div>
      </header>
      <div>
        <input
          type="text"
          id="myInput"
          value={search}
          onChange={(event) => {
            filterProject(event);
          }}
          placeholder="Search"
          title="Type in a name"
          class="form-control"
        />
      </div>
      <div className="table-responsive mt-2">
        {projects.length === 0 ? (
          <div>
            <h2>No Projects Found</h2>
          </div>
        ) : (
          <table className="table table-striped table-light">
            <thead>
              <tr>
                <th>#</th>
                <th>Project</th>
                <th>Key</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>{iterateItem(projects)}</tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Projects;
