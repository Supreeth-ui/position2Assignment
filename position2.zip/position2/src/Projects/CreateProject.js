import React, { useContext, useState } from "react";
import { Link } from "@reach/router";
import Modal from "../Modal/Modal";
import ThemeContext from "../ThemeContext/ThemeContext";

const CreateProject = () => {
  const [theme] = useContext(ThemeContext);
  const [workspace, setworkspace] = useState("");
  const [projectName, setProjectName] = useState("");
  const [projectKey, setProjectKey] = useState("");
  const [showModal, setModal] = useState(false);
  function onSubmit(e) {
    console.log(e);
    toggleModal();
  }

  function toggleModal() {
    console.log("show modal ", showModal);
    setModal(!showModal);
  }
  return (
    <div>
      <header>
        <Link to="/projects">
          <button className="btn" style={{ backgroundColor: theme }}>
            <i class="fas fa-arrow-left pr-1"></i>
            Back
          </button>
        </Link>
      </header>
      <div class="widget-box">
        <header>
          <h2>Create Project</h2>
        </header>
        <form
          className="section"
          onSubmit={(e) => {
            e.preventDefault();
            onSubmit(e);
          }}
        >
          <div className="form-group">
            <label htmlFor="workspaceId">Workspace</label>
            <input
              type="text"
              class="form-control"
              id="workspaceId"
              placeholder="Enter workspace"
              name="workspaceName"
              value={workspace}
              onChange={(e) => setworkspace(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="projectNameId">
              Name
              <span className="MandatoryIcon"> *</span>
            </label>
            <input
              type="text"
              class="form-control"
              id="projectNameId"
              required
              placeholder="Project Name"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="projectKeyId">
              Key
              <span className="MandatoryIcon"> *</span>
            </label>
            <input
              type="text"
              class="form-control"
              id="projectKeyId"
              required
              placeholder="Project Key"
              value={projectName.toLowerCase()}
              onChange={(e) => setProjectKey(e.target.value)}
            />
          </div>
          <button
            className="btn"
            style={{ backgroundColor: theme, display: "flex" }}
          >
            Submit
          </button>
          {showModal ? (
            <Modal>
              <div>
                <h3>Project {projectName} Created Successfully!!! </h3>
                <div className="buttons">
                  <button
                    onClick={(e) => {
                      toggleModal();
                    }}
                  >
                    Ok
                  </button>
                </div>
              </div>
            </Modal>
          ) : null}
        </form>
      </div>
    </div>
    // <p>Create Project</p>
  );
};

export default CreateProject;
