import React, { useContext, useState } from "react";
import ThemeContext from "../ThemeContext/ThemeContext";
import { Link } from "@reach/router";

const Repositories = () => {
  const [state, setState] = useState("");
  const [theme] = useContext(ThemeContext);
  const listOfRepositories = [
    {
      summaryId: "1",
      summaryDescription: "Repo 1",
      builds: "repo1",
      lastUpatedOn: "2020/07/21",
      lastUpatedBy: "Supzz",
    },
    {
      summaryId: "2",
      summaryDescription: "Repo 2",
      builds: "repo2",
      lastUpatedOn: "2020/07/22",
      lastUpatedBy: "Vaibzz",
    },
    {
      summaryId: "3",
      summaryDescription: "Repo 3",
      builds: "repo3",
      lastUpatedOn: "2020/07/23",
      lastUpatedBy: "Puzzz",
    },
  ];
  const [repositories, setRepositories] = useState(listOfRepositories);

  const iterateItem = (item) => {
    return item.map(function (nextItem, j) {
      return (
        <tr key={nextItem.summaryId}>
          <td>{nextItem.summaryId}</td>
          <td>{nextItem.summaryDescription}</td>
          <td>{nextItem.builds}</td>
          <td>{nextItem.lastUpatedOn}</td>
        </tr>
      );
    });
  };

  function filterRepo(event) {
    setState(event.target.value);
    let searchString = event.target.value;
    const filtered = listOfRepositories.filter(
      (item) =>
        item.summaryId.toLowerCase().includes(searchString.toLowerCase()) ||
        item.summaryDescription
          .toLowerCase()
          .includes(searchString.toLowerCase()) ||
        item.builds.toLowerCase().includes(searchString.toLowerCase()) ||
        item.lastUpatedOn.toLowerCase().includes(searchString.toLowerCase())
    );
    console.log("filtered ", filtered);
    if (searchString.trim() !== "") {
      setRepositories(filtered);
    } else if (searchString.trim() === "") {
      setRepositories(listOfRepositories);
    }
  }

  return (
    <div className="content">
      <header>
        <div className="contentHeader">
          <h4>Repositories</h4>
          <Link to="/repositories/createRepositories">
            <button className="btn" style={{ backgroundColor: theme }}>
              Create Repository
            </button>
          </Link>
          {/* <button> Create Project</button> */}
        </div>
      </header>
      <div>
        <input
          type="text"
          id="myInput"
          value={state}
          onChange={(event) => {
            filterRepo(event);
          }}
          placeholder="Search"
          title="Type in a name"
          class="form-control"
        />
      </div>
      <div className="table-responsive mt-2">
        {repositories.length === 0 ? (
          <div>
            <h2>No Repositories Found</h2>
          </div>
        ) : (
          <table className="table table-striped table-light">
            <thead>
              <tr>
                <th>#</th>
                <th>Description</th>
                <th>Builds</th>
                <th>Last updated</th>
              </tr>
            </thead>
            <tbody>{iterateItem(repositories)}</tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default Repositories;
