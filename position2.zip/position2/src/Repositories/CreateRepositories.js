import React, { useContext, useState } from "react";
import { Link } from "@reach/router";
import Modal from "../Modal/Modal";
import ThemeContext from "../ThemeContext/ThemeContext";

const CreateRepositories = () => {
  const [theme] = useContext(ThemeContext);
  const [workspace, setworkspace] = useState("");
  const [project, setProject] = useState("");
  const [repositoryName, setRepositoryName] = useState("");
  const [showModal, setModal] = useState(false);
  function onSubmit(e) {
    console.log(e);
    toggleModal();
  }

  function toggleModal() {
    console.log("show modal ", showModal);
    setModal(!showModal);
  }
  return (
    <div>
      <header>
        <Link to="/repositories">
          <button className="btn" style={{ backgroundColor: theme }}>
            <i class="fas fa-arrow-left pr-1"></i>
            Back
          </button>
        </Link>
      </header>
      <div class="widget-box">
        <header>
          <h2>Create a new repository</h2>
        </header>
        <form
          className="section"
          onSubmit={(e) => {
            e.preventDefault();
            onSubmit(e);
          }}
        >
          <div className="form-group">
            <label htmlFor="workspaceId">Workspace</label>
            <select
              id="repoWorkSpaceId"
              value={workspace}
              className="form-control"
              onChange={(e) => setworkspace(e.target.value)}
              onBlur={(e) => setworkspace(e.target.value)}
            >
              <option value="wrk1">Workspace 1</option>
              <option value="wrk2">Workspace 2</option>
              <option value="wrk3">Workspace 3</option>
              <option value="wrk4">Workspace 4</option>
              <option value="wrk4">Workspace 5</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="projectNameId">
              Project
              <span className="MandatoryIcon"> *</span>
            </label>
            <select
              id="projectNameId"
              required
              value={project}
              className="form-control"
              onChange={(e) => setProject(e.target.value)}
              onBlur={(e) => setProject(e.target.value)}
            >
              <option value="">None</option>
              <option value="pro1">Adopt Pet</option>
              <option value="pro2">Game Builder</option>
              <option value="pro3">Get Insurance</option>
            </select>
          </div>
          <div className="form-group">
            <label htmlFor="repositoryNameId">
              Repository Name
              <span className="MandatoryIcon"> *</span>
            </label>
            <input
              type="text"
              class="form-control"
              id="repositoryNameId"
              required
              placeholder="Repository Name"
              value={repositoryName}
              onChange={(e) => setRepositoryName(e.target.value)}
            />
          </div>
          <button
            className="btn"
            style={{ backgroundColor: theme, display: "flex" }}
          >
            Submit
          </button>
          {showModal ? (
            <Modal>
              <div>
                <h3>Repository {repositoryName} Created Successfully!!! </h3>
                <div className="buttons">
                  <button
                    onClick={(e) => {
                      toggleModal();
                    }}
                  >
                    Ok
                  </button>
                </div>
              </div>
            </Modal>
          ) : null}
        </form>
      </div>
    </div>
    // <p>Create Project</p>
  );
};

export default CreateRepositories;
